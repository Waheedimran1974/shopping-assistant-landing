// ============================================
// CONFIGURATION – REPLACE WITH YOUR LIVE BACKEND URL
// ============================================
const BACKEND_URL = 'https://cheercart-backend.onrender.com/search';

// DOM elements
const queryInput = document.getElementById('queryInput');
const searchBtn = document.getElementById('searchBtn');
const responseDiv = document.getElementById('response');
const micBtn = document.getElementById('micBtn');
const toastEl = document.getElementById('toast');
const themeToggle = document.getElementById('themeToggle');

// ============================================
// THEME TOGGLE (same as before)
// ============================================
let currentTheme = 'system';

function applyTheme(theme) {
    const html = document.documentElement;
    html.classList.remove('light', 'dark');
    if (theme === 'light') html.classList.add('light');
    else if (theme === 'dark') html.classList.add('dark');
    chrome.storage.local.set({ theme: theme });
}

function updateToggleIcon() {
    if (!themeToggle) return;
    if (currentTheme === 'light') themeToggle.textContent = '☀️';
    else if (currentTheme === 'dark') themeToggle.textContent = '🌙';
    else themeToggle.textContent = '🖥️';
}

function initTheme() {
    chrome.storage.local.get(['theme'], (result) => {
        currentTheme = result.theme || 'system';
        applyTheme(currentTheme);
        updateToggleIcon();
    });
}

if (themeToggle) {
    themeToggle.addEventListener('click', () => {
        if (currentTheme === 'system') currentTheme = 'light';
        else if (currentTheme === 'light') currentTheme = 'dark';
        else currentTheme = 'system';
        applyTheme(currentTheme);
        updateToggleIcon();
    });
}

// Helper: show toast
function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.add('show');
    setTimeout(() => toastEl.classList.remove('show'), 1500);
}

// Helper: escape HTML
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function isOnline() { return navigator.onLine; }

function showOfflineMessage() {
    responseDiv.innerHTML = '<div class="offline-state">🌐 No internet connection. Please check your network and try again.</div>';
}

function renderProductCards(products) {
    if (!products || products.length === 0) {
        return '<div class="empty-state">😕 No products found. Try a different search term.</div>';
    }
    let html = '<div style="display: flex; flex-direction: column; gap: 14px;">';
    for (const product of products) {
        const imageHtml = product.image
            ? `<img src="${escapeHtml(product.image)}" loading="lazy" style="width: 60px; height: 60px; object-fit: cover; border-radius: 12px; margin-right: 14px; float: left;">`
            : `<div style="width: 60px; height: 60px; background: #e5e7eb; border-radius: 12px; margin-right: 14px; float: left; display: flex; align-items: center; justify-content: center; font-size: 24px;">🛍️</div>`;
        html += `
            <div class="card" style="overflow: auto;">
                ${imageHtml}
                <div style="margin-left: 74px;">
                    <div class="product-title">${escapeHtml(product.title)}</div>
                    <div class="product-price">${escapeHtml(product.price)}</div>
                    <div class="source-badge">via ${escapeHtml(product.source) || 'eBay'}</div>
                    <div style="margin-top: 10px;">
                        <a href="${escapeHtml(product.link)}" target="_blank" rel="noopener noreferrer" class="product-link">Buy Now →</a>
                        <button class="copy-link-btn" data-link="${escapeHtml(product.link)}">📋 Copy Link</button>
                    </div>
                </div>
            </div>
        `;
    }
    html += '</div>';
    return html;
}

function attachCopyHandlers() {
    document.querySelectorAll('.copy-link-btn').forEach(btn => {
        btn.removeEventListener('click', handleCopy);
        btn.addEventListener('click', handleCopy);
    });
}
function handleCopy(e) {
    const link = e.currentTarget.getAttribute('data-link');
    navigator.clipboard.writeText(link).then(() => showToast('Copied!')).catch(() => showToast('Copy failed'));
}

function showShimmer() {
    let shimmerHtml = '';
    for (let i = 0; i < 3; i++) shimmerHtml += '<div class="shimmer-card"></div>';
    responseDiv.innerHTML = shimmerHtml;
}

async function fetchProducts(query) {
    const resp = await fetch(BACKEND_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
    });
    if (!resp.ok) throw new Error(`Backend error: ${resp.status}`);
    const data = await resp.json();
    // New format: { message, products }
    if (data.products && Array.isArray(data.products)) {
        return data;
    }
    // Fallback for old format
    return { message: null, products: data };
}

async function performSearch() {
    if (!isOnline()) { showOfflineMessage(); return; }
    const query = queryInput.value.trim();
    if (!query) { responseDiv.innerHTML = '<div class="error">Please enter a product name.</div>'; return; }
    showShimmer();
    try {
        const result = await fetchProducts(query);
        const products = result.products || [];
        const message = result.message || null;
        let html = '';
        if (message) {
            html += `<div style="background: var(--card-bg); padding: 12px; border-radius: 16px; margin-bottom: 12px; border-left: 4px solid var(--button-bg); font-style: italic;">🤖 ${escapeHtml(message)}</div>`;
        }
        html += renderProductCards(products);
        responseDiv.innerHTML = html;
        attachCopyHandlers();
    } catch (err) {
        console.error(err);
        responseDiv.innerHTML = `<div class="error">❌ Network error. <button id="retryBtn" style="margin-top: 8px;">Retry</button></div>`;
        document.getElementById('retryBtn')?.addEventListener('click', performSearch);
    }
}

// Voice input, keyboard nav, offline listeners (same as before)
function initVoiceInput() {
    if (!micBtn) return;
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        micBtn.style.display = 'none';
        return;
    }
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    micBtn.addEventListener('click', () => {
        if (micBtn.classList.contains('recording')) {
            recognition.abort();
            micBtn.classList.remove('recording');
            return;
        }
        if (!isOnline()) { showToast('No internet'); return; }
        recognition.start();
        micBtn.classList.add('recording');
    });
    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        queryInput.value = transcript;
        micBtn.classList.remove('recording');
        performSearch();
    };
    recognition.onerror = (event) => {
        micBtn.classList.remove('recording');
        if (event.error === 'not-allowed') showToast('Microphone access denied');
        else showToast('Voice not recognized');
    };
    recognition.onend = () => micBtn.classList.remove('recording');
}

function initKeyboardNav() {
    queryInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); performSearch(); }
        if (e.key === 'Escape') queryInput.value = '';
    });
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            queryInput.focus();
        }
    });
}

window.addEventListener('online', () => {
    if (responseDiv.innerHTML.includes('No internet connection')) {
        responseDiv.innerHTML = '✨ Ask me about any product – I\'ll find the best budget options!';
    }
});
window.addEventListener('offline', () => {
    if (!responseDiv.innerHTML.includes('No internet connection')) showOfflineMessage();
});

if (!isOnline()) showOfflineMessage();

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    searchBtn.addEventListener('click', performSearch);
    initKeyboardNav();
    initVoiceInput();
});